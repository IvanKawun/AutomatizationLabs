package com.example;

public class LibraryClass {
    public String getGreeting1() {
        return "Hello from the Library!";
    }
    public String getGreeting2() {
        return "Hi from the Library!";
    }
}